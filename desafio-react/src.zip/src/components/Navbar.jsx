import PropTypes from "prop-types";
import { Link } from "react-router-dom";

const Navbar = ({ cartCount, total, isLoggedIn, setIsLoggedIn }) => {
  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-light">
      <div className="container-fluid">
        <Link className="navbar-brand" to="/">
          Pizzería Mamma Mía
        </Link>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav ms-auto">
            <li className="nav-item">
              <Link className="btn btn-outline-primary me-2" to="/">
                🍕 Home
              </Link>
            </li>
            {isLoggedIn ? (
              <>
                <li className="nav-item">
                  <Link className="btn btn-outline-primary me-2" to="/profile">
                    🔓 Profile
                  </Link>
                </li>
                <li className="nav-item">
                  <button
                    className="btn btn-outline-danger"
                    onClick={() => {
                      setIsLoggedIn(false);
                    }}
                  >
                    🔒 Logout
                  </button>
                </li>
              </>
            ) : (
              <>
                <li className="nav-item">
                  <Link className="btn btn-outline-primary me-2" to="/login">
                    🔐 Login
                  </Link>
                </li>
                <li className="nav-item">
                  <Link
                    className="btn btn-outline-secondary"
                    to="/register"
                  >
                    🔐 Register
                  </Link>
                </li>
              </>
            )}
            <li className="nav-item">
              <Link className="btn btn-outline-success" to="/cart">
                🛒 Carrito ({cartCount}) - Total: ${total.toLocaleString("es-CL")}
              </Link>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
};

Navbar.propTypes = {
  cartCount: PropTypes.number.isRequired,
  total: PropTypes.number.isRequired,
  isLoggedIn: PropTypes.bool.isRequired,
  setIsLoggedIn: PropTypes.func.isRequired,
};

export default Navbar;
