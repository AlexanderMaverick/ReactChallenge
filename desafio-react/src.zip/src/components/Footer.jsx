const Footer = () => {
  return (
    <footer className="text-center py-3 bg-dark text-white">
      © 2021 - Pizzería Mamma Mía! - Todos los derechos reservados.
    </footer>
  );
};

export default Footer;
