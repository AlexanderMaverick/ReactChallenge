import { useState, useEffect } from 'react';

const Pizza = () => {
  const [pizza, setPizza] = useState(null); 
  const [loading, setLoading] = useState(true); 
  const [error, setError] = useState(null); 

  useEffect(() => {
    const fetchPizza = async () => {
      try {
        const response = await fetch('http://localhost:5000/api/pizzas/p001');
        if (!response.ok) {
          throw new Error(`Error: ${response.statusText}`);
        }
        const data = await response.json();
        setPizza(data); 
      } catch (err) {
        setError(err.message); 
      } finally {
        setLoading(false);
      }
    };

    fetchPizza();
  }, []); 

  if (loading) {
    return <div>Loading pizza...</div>;
  }

  if (error) {
    return <div>No pudimos cargar las pizzas. Por favor, intenta más tarde: {error}</div>;
  }

  return (
    <div className="pizza-details">
      <h2>{pizza.name}</h2>
      <img src={pizza.img} alt={pizza.name} />
      <p><strong>Price:</strong> ${pizza.price}</p>
      <p><strong>Ingredients:</strong> {pizza.ingredients.join(', ')}</p>
      <p><strong>Description:</strong> {pizza.desc}</p>
      <button>Add to Cart</button>
    </div>
  );
};

export default Pizza;
